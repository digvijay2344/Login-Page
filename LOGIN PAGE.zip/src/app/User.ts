export interface user
{

}